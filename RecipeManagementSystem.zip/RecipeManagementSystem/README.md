LARAVEL PROJECT FOR BNCC INTERNAL CLASS

NOTES:
- Data base bernama 'recipemanagement'
- Perlu membuat data base di phpMyAdmin dengan nama 'recipemanagement'
- Lalu ganti file .env(line 14) menjadi DB_DATABASE=recipemanagement
