<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class recipe extends Model
{
    use HasFactory;

    protected $fillable = [
        'RecipeName',
        'Description',
        'CookingTime',
        'RecipeImg',
        'Category_Id'
    ];

    public function category(){
        return $this->belongsTo(Category::class, 'Category_Id'); // 1 recipe hanya 1 kategori
    }
}
