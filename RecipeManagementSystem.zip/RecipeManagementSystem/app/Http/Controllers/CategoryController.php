<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function createCategory(){
        return view('createCategory');
    }

    public function storeCategory(Request $request){
        $request->validate([ // buat validasi - error message
            'CategoryName' => 'required|string'
        ]);

        Category::create([
            'CategoryName' => $request->CategoryName,
        ]);
        return redirect('/');
    }
}
