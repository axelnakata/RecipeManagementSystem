<?php

namespace App\Http\Controllers;

use App\Models\recipe;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;

class RecipeController extends Controller
{
    public function index(){
        $recipes = recipe::all();
        return view('welcome', compact('recipes'));
    }

    public function createRecipe(){
        $categories = Category::all(); // ngambil data dari categori
        return view('createRecipe', compact('categories'));
    }

    public function storeRecipe(Request $request){

        $request->validate([ // buat validasi - error message
            'RecipeName' => 'required|string',
            'Description' => 'required|string|min:5', // min -> minimum stringt length
            'CookingTime'=> 'required|numeric|gt:0', // gt -> greater than
            'RecipeImg' => 'required|mimes:png,jpg' // mimes -> types of file
        ]);

        $recipeImg = $request->file('RecipeImg');
        $filename = Str::random(10).'_'.$recipeImg->getClientOriginalName();
        $recipeImg->storeAs('public/', $filename);

        recipe::create([
            'RecipeName' => $request->RecipeName,
            'Description' => $request->Description,
            'CookingTime'=> $request->CookingTime,
            'RecipeImg' => $filename,
            'Category_Id' => $request->CategoryName
        ]);
        return redirect('/');
    }

    public function updateRecipeView($id){
        $categories = Category::all(); // ngambil data dari categori
        return view('update', ['recipe' => recipe::find($id)], compact('categories'));
    }

    // functions buat update recipenya, then return back to home
    public function updateRecipe(Request $request, $id){
        $request->validate([ // buat validasi - error message
            'RecipeName' => 'string',
            'Description' => 'string|min:5', // min -> minimum stringt length
            'CookingTime'=> 'numeric|gt:0', // gt -> greater than
            'RecipeImg' => 'mimes:png,jpg' // mimes -> types of file
        ]);

        $recipeImg = $request->file('RecipeImg');
        $recipe = recipe::findOrFail($id);
        // validasi jika ada file yang disubmit - NOT NULL
        if($recipeImg){
            Storage::delete('public/'.$recipe->RecipeImg);
            $filename = Str::random(10).'_'.$recipeImg->getClientOriginalName();
            $recipeImg->storeAs('public/', $filename);
            $recipe->update([
                'RecipeImg' => $filename
            ]);
        }
        
        // id dari parameter atas itu sesuain sama yang ada di web.php
        recipe::findOrFail($id)->update([
            'RecipeName' =>$request->RecipeName,
            'Description' => $request->Description,
            'CookingTime'=> $request->CookingTime,
            'Category_Id' => $request->CategoryName
        ]);
        return redirect(route('home'));
    }

    // functions to remove a data
    public function deleteRecipe($id){
        $recipe = recipe::findOrFail($id); // find data
        $recipe->delete(); // delete data

        Storage::delete('public/'.$recipe->RecipeImg); // delete photos

        return redirect(route('home'));
    }
}
