<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Create Recipe</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
<body>
    <div class="m-5">
        <h1>Create Recipe</h1>
        <a href="/" class="btn btn-secondary">Return Home</a>
        <hr style="border-top: 5px solid black;">
        <form action = "/store-recipe" method = "POST" enctype="multipart/form-data">
            @csrf
            <div class="mb-3">
                <label for="" class="form-label">Recipe Name</label>
                <input type="text" class="form-control @error('RecipeName') is-invalid @enderror" id="exampleInputEmail1" name="RecipeName" value="{{ old('RecipeName') }}">
            </div>
            @error('RecipeName')
                <div class="alert alert-danger" role="alert">
                    {{$message}}
                </div>
            @enderror

            <div class="mb-3">
                <label for="" class="form-label">Description (min 5 characters)</label>
                <input type="text" class="form-control @error('Description') is-invalid @enderror" id="exampleInputEmail1" name="Description" value="{{ old('Description') }}">
            </div>
            @error('Description')
                <div class="alert alert-danger" role="alert">
                    {{$message}}
                </div>
            @enderror

            <div class="mb-3">
                <label for="" class="form-label">Cooking Time - minutes (min 1)</label>
                <input type="number" class="form-control @error('CookingTime') is-invalid @enderror" id="exampleInputEmail1" name="CookingTime">
            </div>
            @error('CookingTime')
                <div class="alert alert-danger" role="alert">
                    {{$message}}
                </div>
            @enderror

            <div class="mb-3">
                <label for="" class="form-label">Recipe Image (png/jpg)</label>
                <input type="file" class="form-control @error('RecipeImg') is-invalid @enderror" id="exampleInputEmail1" name="RecipeImg" value="{{ old('RecipeImg') }}">
            </div>
            @error('RecipeImg')
                <div class="alert alert-danger" role="alert">
                    {{$message}}
                </div>
            @enderror

            <div class="mb-3">
                <label for="" class="form-label">Category</label>
                <select class="form-select" aria-label="Default select example" name="CategoryName">
                    <option selected>Choose Category</option>
                    @foreach ($categories as $c)
                        <option value="{{$c->id}}">{{ $c->CategoryName }}</option>
                    @endforeach
                  </select>
            </div>

            <button type="submit" class="btn btn-success">Submit</button>
          </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>
</html>