<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Recipe Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
<body>
    <h1>Welcome to Recipe Management System!</h1>
    <hr style="border-top: 5px solid black;">
    <h3>Create New Recipe: <a href="/create-recipe" class="btn btn-primary">New Recipe</a></h3>
    <h3>Create New Category: <a href="/create-category" class="btn btn-primary">New Category</a></h3>

    {{-- CARD
    <div class="m-5">
        @foreach ($recipes as $r)
        <div class="card m-4" style="width: 18rem;">
            <img src="{{ asset('storage/'. $r->RecipeImg) }}" class="card-img-top" alt="...">
            <div class="card-body">
                <h1 class="card-title">{{$r->RecipeName}}</h1>
                <p class="card-text">{{ $r->Description }}</p>
                <p>{{ $r->CookingTime }}</p>
                <p>{{ $r->category->CategoryName }}</p>
                <a href="/update-recipe/{{$r->id}}" class="btn btn-primary">Edit Recipe</a>
                <form action="/delete-recipe/{{$r->id}}" method="post">
                    @csrf
                    @method('DELETE')
                <button type="submit" class="btn btn-primary">Delete</button></form>
            </div>
        </div>
        @endforeach
    </div> --}}

    <div class="m-5 d-flex flex-wrap justify-content-around">
        @foreach ($recipes as $r)
        <div class="card mb-4" style="width: 18rem; box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);">
          <img src="{{ asset('storage/'. $r->RecipeImg) }}" class="card-img-top" alt="...">
          <div class="card-body" style="max-height: 10rem; line-height: 1.2;">
            <h1 class="card-title" style="font-size: 1.5rem; margin-bottom: 0.5rem;">{{$r->RecipeName}}</h1>
            <h6 class="card-text">{{ $r->Description }}</h6>
          </div>
          <ul class="list-group list-group-flush">
            <li class="list-group-item">Cooking Time: {{ $r->CookingTime }} minute(s)</li>
            <li class="list-group-item">Category: {{ $r->category->CategoryName }}</li>
          </ul>
          <div class="card-body d-flex justify-content-between">
            <a href="/update-recipe/{{$r->id}}" class="btn btn-warning">Edit Recipe</a>
            <form action="/delete-recipe/{{$r->id}}" method="post">
              @csrf
              @method('DELETE')
              <button type="submit" class="btn btn-danger">Delete</button>
            </form>
          </div>
        </div>
        @endforeach
      </div>
      
      

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>
</html>