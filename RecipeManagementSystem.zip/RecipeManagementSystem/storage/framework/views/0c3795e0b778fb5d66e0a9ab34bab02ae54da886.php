<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Recipe Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
</head>
<body>
    <h1>Welcome to Recipe Management System!</h1>
    <hr style="border-top: 5px solid black;">
    <h3>Create New Recipe: <a href="/create-recipe" class="btn btn-primary">New Recipe</a></h3>
    <h3>Create New Category: <a href="/create-category" class="btn btn-primary">New Category</a></h3>

    

    <div class="m-5 d-flex flex-wrap justify-content-around">
        <?php $__currentLoopData = $recipes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-4" style="width: 18rem; box-shadow: 0 0 10px rgba(0, 0, 0, 0.3);">
          <img src="<?php echo e(asset('storage/'. $r->RecipeImg)); ?>" class="card-img-top" alt="...">
          <div class="card-body" style="max-height: 10rem; line-height: 1.2;">
            <h1 class="card-title" style="font-size: 1.5rem; margin-bottom: 0.5rem;"><?php echo e($r->RecipeName); ?></h1>
            <h6 class="card-text"><?php echo e($r->Description); ?></h6>
          </div>
          <ul class="list-group list-group-flush">
            <li class="list-group-item">Cooking Time: <?php echo e($r->CookingTime); ?> minute(s)</li>
            <li class="list-group-item">Category: <?php echo e($r->category->CategoryName); ?></li>
          </ul>
          <div class="card-body d-flex justify-content-between">
            <a href="/update-recipe/<?php echo e($r->id); ?>" class="btn btn-warning">Edit Recipe</a>
            <form action="/delete-recipe/<?php echo e($r->id); ?>" method="post">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" class="btn btn-danger">Delete</button>
            </form>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
      
      

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>
</body>
</html><?php /**PATH D:\Documents\UNIV\BNCC\Laravel Training Program\RecipeManagementSystem\resources\views/welcome.blade.php ENDPATH**/ ?>