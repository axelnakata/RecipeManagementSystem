<?php

use App\Http\Controllers\RecipeController;
use App\Http\Controllers\CategoryController;
use App\Models\recipe;use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [RecipeController::class, 'index'])->name('home');

Route::get('/create-recipe', [RecipeController::class, 'createRecipe']);

Route::post('/store-recipe', [RecipeController::class, 'storeRecipe']);

// View Update
Route::get('/update-recipe/{id}', [RecipeController::class, 'updateRecipeView']);

// update data from view
Route::patch('/update/{id}', [RecipeController::class, 'updateRecipe']);

// delete data
Route::delete('delete-recipe/{id}', [RecipeController::class, 'deleteRecipe']);

// category view
Route::get('/create-category', [CategoryController::class, 'createCategory'])->name('createCategory');

// store category
Route::post('/store-category', [CategoryController::class, 'storeCategory'])->name('storeCategory');